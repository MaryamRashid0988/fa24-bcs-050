class UserInfo{

static String username = "maryam.098";
static String password = "ibrahimisdumb";

}